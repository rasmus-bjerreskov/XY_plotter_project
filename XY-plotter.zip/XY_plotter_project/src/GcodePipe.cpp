#include "GcodePipe.h"

GcodePipe::~GcodePipe() {

}
